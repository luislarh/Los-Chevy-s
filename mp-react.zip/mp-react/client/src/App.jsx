import Product from "./Components/Product/Product"
function App() {
  return (
    <>
      <Product />
    </>
  );
}

export default App;
