const express = require("express");
const app = express();
const cors = require("cors");
const mercadopago = require("mercadopago");

app.use(express.json());
app.use(cors());


    mercadopago.configure({
        //aqui se pone el access token (lo que se hace en la pagina de mercadopago checkout pro)
        access_token: "",
    });
  

    app.get("/", function(req, res){
        res.send("el servidor esta corriendo satisfactoriamente");
    });

    app.post("/create_preference", (req, res) => {
        let preference = {
        items: [
            {
            title: req.body.description,
            unit_price: Number(req.body.price),
            quantity: Number(req.body.quantity),
            },
        ],
        back_urls: {
            //A estas url's se retornara la pagina si la compra fue exitosa o fallida
            success: "http://localhost:5173",
            failure: "http://localhost:5173",
            pending: "",
        },
        auto_return: "approved",
        };
    
        mercadopago.preferences
        .create(preference)
        .then(function (response) {
            res.json({
            id: response.body.id,
            });
        })
        .catch(function (error) {
            console.log(error);
        });
    });


    app.listen(8080, ()=>{
        console.log("El servidor esta corriendo en el puerto 8080");
    });